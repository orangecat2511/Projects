import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { incrementItem, decrementItem, removeItem } from "../redux/actions";

const ShoppingCart = () => {
  const cart = useSelector((state) => state.cart.items);
  const totalItems = useSelector((state) => state.cart.totalItems);
  const totalCost = useSelector((state) => state.cart.totalCost);
  const dispatch = useDispatch();

  return (
    <div className="shopping-cart">
      <h1>Shopping Cart</h1>
      {cart.length === 0 ? (
        <p>Your cart is empty</p>
      ) : (
        <div>
          {cart.map((item) => (
            <div key={item.id} className="cart-item">
              <img src={item.thumbnail} alt={item.name} />
              <h3>{item.name}</h3>
              <p>${item.price}</p>
              <div>
                <button onClick={() => dispatch(decrementItem(item.id))}>-</button>
                <span>{item.quantity}</span>
                <button onClick={() => dispatch(incrementItem(item.id))}>+</button>
                <button onClick={() => dispatch(removeItem(item.id))}>Delete</button>
              </div>
            </div>
          ))}
          <p>Total Items: {totalItems}</p>
          <p>Total Cost: ${totalCost.toFixed(2)}</p>
          <button onClick={() => alert("Coming Soon")}>Checkout</button>
        </div>
      )}
      <button onClick={() => window.location.assign("/products")}>
        Continue Shopping
      </button>
    </div>
  );
};

export default ShoppingCart;

import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { addToCart } from "../redux/actions";

const ProductListing = () => {
  const dispatch = useDispatch();
  const products = useSelector((state) => state.products);

  return (
    <div className="product-listing">
      {Object.keys(products).map((category) => (
        <div key={category}>
          <h2>{category}</h2>
          <div className="products">
            {products[category].map((product) => (
              <div key={product.id} className="product">
                <img src={product.thumbnail} alt={product.name} />
                <h3>{product.name}</h3>
                <p>${product.price}</p>
                <button
                  onClick={() => dispatch(addToCart(product.id))}
                  disabled={product.inCart}
                >
                  {product.inCart ? "Added to Cart" : "Add to Cart"}
                </button>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
};

export default ProductListing;

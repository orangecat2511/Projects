const initialState = {
    products: {
      Indoor: [
        { id: 1, name: "Fern", price: 15, thumbnail: "/fern.jpg", inCart: false },
        { id: 2, name: "Snake Plant", price: 20, thumbnail: "/snake.jpg", inCart: false },
      ],
      Outdoor: [
        { id: 3, name: "Cactus", price: 25, thumbnail: "/cactus.jpg", inCart: false },
        { id: 4, name: "Palm", price: 50, thumbnail: "/palm.jpg", inCart: false },
      ],
      Flowering: [
        { id: 5, name: "Orchid", price: 30, thumbnail: "/orchid.jpg", inCart: false },
        { id: 6, name: "Rose", price: 10, thumbnail: "/rose.jpg", inCart: false },
      ],
    },
    cart: {
      items: [],
      totalItems: 0,
      totalCost: 0,
    },
  };
  
  const reducer = (state = initialState, action) => {
    // Handle cart logic based on action types
  };
  
  export default reducer;
  